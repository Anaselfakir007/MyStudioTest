package com.mystudio.developerstestapp.data

data class ErrorResponse(val message: String)