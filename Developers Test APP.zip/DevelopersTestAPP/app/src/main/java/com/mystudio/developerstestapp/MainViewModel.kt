package com.mystudio.developerstestapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.mystudio.developerstestapp.api.DevelopersHelper
import com.mystudio.developerstestapp.api.builder.ApiBuilder
import com.mystudio.developerstestapp.data.Resource

import com.mystudio.developerstestapp.repository.DevelopersRepository

class MainViewModel() : ViewModel() {


    fun getDevelopers() = liveData {
            emit(Resource.loading(null))
            emit(ApiBuilder.apiService.getAllDevelopers())

    }
}